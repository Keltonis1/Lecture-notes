import pygame, sys
from pygame.locals import *  # Pygame constants

pygame.init() # Initialize the pygame subsystem

DISPLAYSURF = pygame.display.set_mode((400, 400)) # Set window size

pygame.display.set_caption('Drawing!') # Set the title of the window

#clock = pygame.time.Clock()

# RGB colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0,255)

FPS = 60

while True: # main game loop


    # Process events
    for event in pygame.event.get(): # Events from the events 
        if event.type == QUIT: # Close window event
            pygame.quit() # shutdown pygame subsystem
            sys.exit() # exit program
    
    pygame.display.update() # Update the display
