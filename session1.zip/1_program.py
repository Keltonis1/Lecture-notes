import pygame, sys
from pygame.locals import *  # Pygame constants

pygame.init() # Initialize the pygame subsystem

DISPLAYSURF = pygame.display.set_mode((800, 600)) # Set window size

pygame.display.set_caption('Hello World!') # Set the title of the window

while True: # main game loop

    for event in pygame.event.get(): # Events from the events 
        if event.type == QUIT: # Close window event
            pygame.quit() # shutdown pygame subsystem
            sys.exit() # exit program
            
    pygame.display.update()
