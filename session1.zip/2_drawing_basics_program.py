import pygame, sys
from pygame.locals import *  # Pygame constants

pygame.init() # Initialize the pygame subsystem

DISPLAYSURF = pygame.display.set_mode((400, 400)) # Set window size

pygame.display.set_caption('Drawing!') # Set the title of the window

# RGB colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN =(0, 255, 0)
BLUE = (0, 0, 255)


DISPLAYSURF.fill(WHITE) # Fill a background color

pygame.draw.polygon(DISPLAYSURF, GREEN, ((146, 0), (291, 106), (236, 277), (56, 277), (0, 106)), 10) # Color and points optional width. 0 fill 

pygame.draw.line(DISPLAYSURF, BLUE, (60, 60), (120, 60), 4) # x start, y start, thickness
pygame.draw.line(DISPLAYSURF, BLUE, (120, 60), (60, 120))
pygame.draw.line(DISPLAYSURF, BLUE, (60, 120), (120, 120), 4)

pygame.draw.circle(DISPLAYSURF, BLUE, (300, 50), 20, 4) # Color, center point, radius, fill
pygame.draw.ellipse(DISPLAYSURF, RED, (300, 250, 80, 80), 1)

pygame.draw.rect(DISPLAYSURF, RED, (200, 150, 100, 150)) # Optional width 0 - fill 


while True: # main game loop

    for event in pygame.event.get(): # Events from the events 
        if event.type == QUIT: # Close window event
            pygame.quit() # shutdown pygame subsystem
            sys.exit() # exit program
            
    pygame.display.update() # Update the display
